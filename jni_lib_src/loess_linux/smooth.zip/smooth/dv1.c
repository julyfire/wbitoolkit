#include <stdio.h>
#include "loess.h"

struct  loess_struct    dv1;
struct pred_struct dv1_pred;
double	x[] = {0};
double	y[] = {0.2181818269};
long    n = 2306, p = 1;

main() {
        printf("\nloess(&dv1):\n");
        loess_setup(x, y, n, p, &dv1);
        dv1.model.span = 300.0/2306;
        loess(&dv1);
        loess_summary(&dv1);
	
	long se_fit=FALSE;
	predict(x, n, &dv1, &dv1_pred, se_fit);
	int i;
	for(i=0; i<n; i++)
		printf("%g\n", dv1_pred.fit[i]);        

        loess_free_mem(&dv1);
	/*loess_free_mem(&dv1_pred);*/ 
}
