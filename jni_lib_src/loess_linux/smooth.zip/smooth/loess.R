d<-read.table("./d")
x<-d[[1]]
y<-d[[2]]
y.loess<-loess(y~x,span=0.2,d)
sy<-predict(y.loess,data.frame(x=x))
plot(x,sy,type="l")
abline(h=0)
abline(v=441)
abline(v-698)
x11(); #open a new plot window
plot(x,sy);
par(mfrow=c(2,1));#create a plot window which includes two rows and 1 column
plot(x,sy); #plot 1
plot(x,sy); #plot 2

plot(lowess(d, f=0.2)) #lowess

